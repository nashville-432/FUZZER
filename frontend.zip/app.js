document.addEventListener('DOMContentLoaded', () => {
    const targetUrlInput = document.getElementById('target-url');
    const payloadsInput = document.getElementById('payloads');
    const delayInput = document.getElementById('delay');
    const startBtn = document.getElementById('start-btn');
    const stopBtn = document.getElementById('stop-btn');
    const statusIndicator = document.getElementById('status-indicator');
    const resultsBody = document.getElementById('results-body');
    const statusText = statusIndicator.querySelector('.text');

    let pollInterval = null;

    startBtn.addEventListener('click', async () => {
        const targetUrl = targetUrlInput.value.trim();
        const delayMs = parseInt(delayInput.value) || 100;
        const intensity = document.getElementById('intensity').value;

        if (!targetUrl) {
            alert("Please provide a Base Target URL.");
            return;
        }

        const tableContainer = document.querySelector('.table-container');
        tableContainer.className = 'table-container glow-' + intensity;

        try {
            const response = await fetch('/api/start', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    target_url: targetUrl,
                    intensity: intensity,
                    delay_ms: delayMs
                })
            });

            const data = await response.json();
            
            if (data.status === 'success') {
                setRunningState(true);
                resultsBody.innerHTML = ''; // Clear previous results
                startPolling();
            } else {
                alert(data.message);
            }
        } catch (error) {
            console.error("Error starting fuzzer:", error);
            alert("Failed to start fuzzer. Is the backend running?");
        }
    });

    stopBtn.addEventListener('click', async () => {
        try {
            await fetch('/api/stop', { method: 'POST' });
            setRunningState(false);
            stopPolling();
            // Do one last poll to get final results
            fetchResults();
        } catch (error) {
            console.error("Error stopping fuzzer:", error);
        }
    });

    function setRunningState(isRunning) {
        if (isRunning) {
            startBtn.disabled = true;
            stopBtn.disabled = false;
            statusIndicator.classList.add('running');
            statusText.textContent = 'ATTACKING';
        } else {
            startBtn.disabled = false;
            stopBtn.disabled = true;
            statusIndicator.classList.remove('running');
            statusText.textContent = 'IDLE';
        }
    }

    function startPolling() {
        if (pollInterval) clearInterval(pollInterval);
        pollInterval = setInterval(fetchResults, 1000);
    }

    function stopPolling() {
        if (pollInterval) {
            clearInterval(pollInterval);
            pollInterval = null;
        }
    }

    async function fetchResults() {
        try {
            const response = await fetch('/api/results');
            const data = await response.json();

            renderResults(data.results);

            if (!data.is_running && statusIndicator.classList.contains('running')) {
                setRunningState(false);
                stopPolling();
            }
        } catch (error) {
            console.error("Error fetching results:", error);
        }
    }

    function renderResults(results) {
        resultsBody.innerHTML = '';
        
        results.forEach(result => {
            const tr = document.createElement('tr');
            
            let statusClass = 'status-0';
            if (result.status_code >= 200 && result.status_code < 300) statusClass = 'status-2xx';
            else if (result.status_code >= 300 && result.status_code < 400) statusClass = 'status-3xx';
            else if (result.status_code >= 400 && result.status_code < 500) statusClass = 'status-4xx';
            else if (result.status_code >= 500) statusClass = 'status-5xx';

            tr.innerHTML = `
                <td class="payload-cell" title="${escapeHtml(result.payload)}">${escapeHtml(result.payload)}</td>
                <td class="${statusClass}">${result.status_code || 'ERR'}</td>
                <td>${result.length}</td>
                <td>${result.time_ms}</td>
                <td class="payload-cell" title="${escapeHtml(result.error || '')}">${escapeHtml(result.error || '-')}</td>
            `;
            
            resultsBody.appendChild(tr);
        });
        
        // Scroll to bottom
        const container = document.querySelector('.table-container');
        container.scrollTop = container.scrollHeight;
    }

    function escapeHtml(unsafe) {
        if (unsafe === null || unsafe === undefined) return '';
        return unsafe
             .toString()
             .replace(/&/g, "&amp;")
             .replace(/</g, "&lt;")
             .replace(/>/g, "&gt;")
             .replace(/"/g, "&quot;")
             .replace(/'/g, "&#039;");
    }
});
